class Black < Scene
  def initialize
    super()
    @background.fill([0,0,0])
  end
end