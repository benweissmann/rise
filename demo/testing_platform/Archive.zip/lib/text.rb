module EasyRubygame
  class TextSprite < Sprite
    def initialize font, size
    end
  end
end
